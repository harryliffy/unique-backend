  echo'<script>
								function nac() {


if ( document.getElementById("collapse-dashboards").classList.contains("show") )

document.getElementById("collapse-dashboards").classList.toggle("show");


}
								
								
								</script>';
								
								
								
								
								
								
								
								
								
								
								  echo'<script>
								function nac() {
document.getElementById("de collapse-dashboards").classList.remove("show");
document.getElementById("collapse-ecommerce").className += " show";

document.getElementById("div12").className += " active";
}
								
								
								</script>';

