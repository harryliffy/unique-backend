<?php
session_start();

if(!isset($_SESSION['vendor_session']))
{
	header("Location:login");
}

?>
<?php
include('header.php');
?>
                <div class="content">
                    <div id="e-commerce-product" class="page-layout simple tabbed">

                        <!-- HEADER -->
                        <div
                            class="page-header bg-primary text-auto row no-gutters align-items-center justify-content-between p-6">

                            <div class="row no-gutters align-items-center">

                                <a href="products" class="btn btn-icon mr-4">
                                    <i class="icon icon-arrow-left"></i>
                                </a>

                                <div class="product-image mr-4">
                                    <img src="../assets/images/ecommerce/product-image-placeholder.png">
                                </div>

                                <div>Product Detail</div>
                            </div>

                            <button type="button" class="btn btn-secondary" disabled>
                                SAVE
                            </button>

                        </div>
                        <!-- / HEADER -->

                        <!-- CONTENT -->
                        <div class="page-content">

                            <ul class="nav nav-tabs" id="myTab" role="tablist">

                                <li class="nav-item">
                                    <a class="nav-link btn active" id="basic-info-tab" data-toggle="tab"
                                       href="#basic-info-tab-pane"
                                       role="tab" aria-controls="basic-info-tab-pane" aria-expanded="true">Basic
                                        Info</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link btn" id="product-images-tab" data-toggle="tab"
                                       href="#product-images-tab-pane"
                                       role="tab" aria-controls="product-images-tab-pane">Product Images</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link btn" id="pricing-tab" data-toggle="tab" href="#pricing-tab-pane"
                                       role="tab" aria-controls="pricing-tab-pane">Pricing</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link btn" id="inventory-tab" data-toggle="tab"
                                       href="#inventory-tab-pane"
                                       role="tab" aria-controls="inventory-tab-pane">Inventory</a>
                                </li>

                                <li class="nav-item">
                                    <a class="nav-link btn" id="shipping-tab" data-toggle="tab"
                                       href="#shipping-tab-pane"
                                       role="tab" aria-controls="shipping-tab-pane">Shipping</a>
                                </li>

                            </ul>

                            <div class="tab-content">

                                <div class="tab-pane fade show active" id="basic-info-tab-pane" role="tabpanel"
                                     aria-labelledby="basic-info-tab">

                                    <div class="card p-6">

                                        <form>

                                            <div class="form-group">
                                                <input type="text" class="form-control"
                                                       aria-describedby="product name"/>
                                                <label>Product Name</label>
                                            </div>

                                            <div class="form-group">
                                                <textarea class="form-control" aria-describedby="product description"
                                                          rows="5"></textarea>
                                                <label>Product Description</label>
                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control"
                                                       aria-describedby="product categories"/>
                                                <label>Categories</label>
                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control"
                                                       aria-describedby="product tags"/>
                                                <label>Tags</label>
                                            </div>

                                        </form>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="product-images-tab-pane" role="tabpanel"
                                     aria-labelledby="product-images-tab">

                                    <div class="card p-6">

                                        <div class="row">

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/january.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/february.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/march.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/april.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/may.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/june.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/july.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/august.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/september.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/october.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/november.jpg">
                                            </div>

                                            <div class="product-image m-2">
                                                <img class="w-100" src="../assets/images/backgrounds/december.jpg">
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="pricing-tab-pane" role="tabpanel"
                                     aria-labelledby="pricing-tab">

                                    <div class="card p-6">

                                        <form>

                                            <div class="input-group mb-8">

                                                <span class="input-group-addon">$</span>

                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                           aria-label="Amount (to the nearest dollar)"/>
                                                    <label>Tax Excluded Price</label>
                                                </div>

                                                <span class="input-group-addon">.00</span>

                                            </div>

                                            <div class="input-group mb-8">

                                                <span class="input-group-addon">$</span>

                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                           aria-label="Amount (to the nearest dollar)"/>
                                                    <label>Tax Included Price</label>
                                                </div>

                                                <span class="input-group-addon">.00</span>

                                            </div>

                                            <div class="input-group mb-8">

                                                <span class="input-group-addon">%</span>

                                                <div class="form-group">
                                                    <input type="text" class="form-control" aria-label="taxt rate"/>
                                                    <label>Tax Rate</label>
                                                </div>

                                            </div>

                                            <div class="input-group mb-8">

                                                <span class="input-group-addon">$</span>

                                                <div class="form-group">
                                                    <input type="text" class="form-control"
                                                           aria-label="Amount (to the nearest dollar)"/>
                                                    <label>Compared Price</label>
                                                    <small class="form-text text-muted">Add a compare price to show next
                                                        to the real price
                                                    </small>
                                                </div>

                                                <span class="input-group-addon">.00</span>

                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <div class="tab-pane fade" id="inventory-tab-pane" role="tabpanel"
                                     aria-labelledby="inventory-tab">

                                    <div class="card p-6">

                                        <form>

                                            <div class="form-group">
                                                <input type="text" class="form-control" aria-describedby="sku"/>
                                                <label>SKU</label>
                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control" aria-describedby="barcode"/>
                                                <label>Barcode</label>
                                            </div>

                                            <div class="form-group">
                                                <input class="form-control" type="number" value="42"
                                                       aria-describedby="quantity"/>
                                                <label for="example-number-input">Quantity</label>
                                            </div>

                                        </form>
                                    </div>
                                </div>

                                <div class="tab-pane fade" id="shipping-tab-pane" role="tabpanel"
                                     aria-labelledby="shipping-tab">

                                    <div class="card p-6">

                                        <form>

                                            <div class="row">

                                                <div class="col-4">

                                                    <div class="form-group">
                                                        <input type="text" class="form-control"
                                                               aria-describedby="width"/>
                                                        <label>Width</label>
                                                    </div>

                                                </div>

                                                <div class="col-4">

                                                    <div class="form-group">
                                                        <input type="text" class="form-control"
                                                               aria-describedby="height"/>
                                                        <label>Height</label>
                                                    </div>

                                                </div>

                                                <div class="col-4">

                                                    <div class="form-group">
                                                        <input type="text" class="form-control"
                                                               aria-describedby="depth"/>
                                                        <label>Depth</label>
                                                    </div>

                                                </div>

                                            </div>

                                            <div class="form-group">
                                                <input type="text" class="form-control" aria-describedby="weight"/>
                                                <label>Weight</label>
                                            </div>

                                            <div class="form-group">
                                                <input class="form-control" type="number" value="42"
                                                       aria-describedby="quantity"/>
                                                <label for="example-number-input">Quantity</label>
                                            </div>

                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- / CONTENT -->
                    </div>

                    <script type="text/javascript" src="../assets/js/apps/e-commerce/product/product.js"></script>
                </div>

            </div>

            <div class="quick-panel-sidebar" fuse-cloak data-fuse-bar="quick-panel-sidebar"
                 data-fuse-bar-position="right">
                <div class="list-group" class="date">

                    <div class="list-group-item subheader">TODAY</div>

                    <div class="list-group-item two-line">

                        <div class="text-muted">

                            <div class="h1"> Monday</div>

                            <div class="h2 row no-gutters align-items-start">
                                <span> 12</span>
                                <span class="h6">th</span>
                                <span> Jun</span>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="divider"></div>

                <div class="list-group">

                    <div class="list-group-item subheader">Events</div>

                    <div class="list-group-item two-line">

                        <div class="list-item-content">

                            <h3>Group Meeting</h3>

                            <p>In 32 Minutes, Room 1B</p>
                        </div>

                    </div>

                    <div class="list-group-item two-line">

                        <div class="list-item-content">

                            <h3>Public Beta Release</h3>

                            <p>11:00 PM</p>
                        </div>

                    </div>

                    <div class="list-group-item two-line">

                        <div class="list-item-content">

                            <h3>Dinner with David</h3>

                            <p>17:30 PM</p>
                        </div>

                    </div>

                    <div class="list-group-item two-line">

                        <div class="list-item-content">

                            <h3>Q&A Session</h3>

                            <p>20:30 PM</p>
                        </div>

                    </div>

                </div>

                <div class="divider"></div>

                <div class="list-group">

                    <div class="list-group-item subheader">Notes</div>

                    <div class="list-group-item two-line">

                        <div class="list-item-content">

                            <h3>Best songs to listen while working</h3>

                            <p>Last edit: May 8th, 2015</p>
                        </div>

                    </div>

                    <div class="list-group-item two-line">

                        <div class="list-item-content">

                            <h3>Useful subreddits</h3>

                            <p>Last edit: January 12th, 2015</p>
                        </div>

                    </div>

                </div>

                <div class="divider"></div>

                <div class="list-group">

                    <div class="list-group-item subheader">Quick Settings</div>

                    <div class="list-group-item">

                        <div class="list-item-content">
                            <h3>Notifications</h3>
                        </div>

                        <div class="secondary-container">
                            <label class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"/>
                                <span class="custom-control-indicator"></span>
                            </label>
                        </div>

                    </div>

                    <div class="list-group-item">

                        <div class="list-item-content">
                            <h3>Cloud Sync</h3>
                        </div>

                        <div class="secondary-container">
                            <label class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"/>
                                <span class="custom-control-indicator"></span>
                            </label>
                        </div>

                    </div>

                    <div class="list-group-item">

                        <div class="list-item-content">
                            <h3>Retro Thrusters</h3>
                        </div>

                        <div class="secondary-container">

                            <label class="custom-control custom-checkbox">
                                <input type="checkbox" class="custom-control-input"/>
                                <span class="custom-control-indicator"></span>
                            </label>

                        </div>
                    </div>
                </div>
            </div>

        </div>

    </body>

<!-- Mirrored from fuse-bootstrap4-material.withinpixels.com/vertical-layout-below-toolbar-left-navigation/apps-e-commerce-product.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 02 Jul 2017 09:20:23 GMT -->
</html>