Author: Yogesh singh
Author URL: http://makitweb.com/
Author Email: yogesh@makitweb.com
Tutorial Link: http://makitweb.com/how-to-delete-record-from-mysql-table-with-ajax/

Instructions -

## Import attached posts.sql file in your MySQL database.
## Update config.php file.
